#include "Shape.h"

/**
 * Default Shape constructor
 */
Shape::Shape()
{
}
/**
 * Shape constructor
 * @param shapeName the name of the shape
 * @param shapePoints the points that make up the shape
 */
Shape::Shape(std::string shapeName, std::vector<Point> shapePoints)
{
    name = shapeName;
    for (int i = 0; i < shapePoints.size(); i++)
    {
        points[i].set(shapePoints[i].getX(), shapePoints[i].getY());
    }
}

/**
 * getter function
 * @return name of shape
 */
std::string Shape::getName()
{
    return name;
}

/**
 * getter function
 * @return area of shape
 */
double Shape:: getArea()
{
    return area;
}