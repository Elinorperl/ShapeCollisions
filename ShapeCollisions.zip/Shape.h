#ifndef EX2_SHAPES_H
#define EX2_SHAPES_H

#include <iostream>
#include <cmath>
#include "Point.h"
#include <vector>

class Shape
{
public:
    /*
     * Default shape constructor
     */
    Shape();
    /**
     * shape constructor
     * @param shapeName shape name
     * @param shapePoints points that make up the shape
     */
    Shape(std::string shapeName, std::vector<Point> shapePoints);
    /**
     * default destructor
     */
    inline virtual ~Shape()
    {}
    /**
     * getter function
     * @return shape area
     */
    double getArea();
    /**
 * getter function
 * @return shape name
 */
    std::string getName();
    /**
     * points that make up the shape.
     */
    std::vector<Point> points;

protected:
    /**
     * shape name
     */
    std::string name;
    /**
     * shape area
     */
    double area;
    /**
     * abstract function - calculates that area of a shape.
     */
    virtual void calculateArea() = 0;
};

#endif //EX2_SHAPES_H

