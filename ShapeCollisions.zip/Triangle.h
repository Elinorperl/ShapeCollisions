#ifndef EX2_TRIANGLE_H
#define EX2_TRIANGLE_H

#include "Shape.h"

/**
 * Triangle class that inherits from Shapes
 */
class Triangle : public Shape
{
public:
    /**
     * Triangle constructor
     * @param created by an area of three points
     */
    Triangle(std::vector<Point> &givenPoints);

    static Triangle* createTriangle(std::vector<Point> &givenPoints);


private:
    /**
     * calculates area of triangle.
     */
    virtual void calculateArea();
    static bool isTriangleLegal (std::vector<Point> givenPoints);
};

#endif //EX2_TRIANGLE_H
