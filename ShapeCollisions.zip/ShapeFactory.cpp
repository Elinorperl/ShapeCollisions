#include "ShapeFactory.h"

Shape* ShapeFactory::createShape (char shapeType, std::vector<Point> points)
{
    switch (shapeType)
    {
        case 'T':
        {
            return Triangle::createTriangle(points);
        }
        case 't':
        {
            return Trapezoid::createTrapezoid(points);
        }
        default:
            return NULL;
    }
}
