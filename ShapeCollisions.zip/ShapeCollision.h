#ifndef EX2_SHAPECOLLISION_H
#define EX2_SHAPECOLLISION_H

#include <vector>
#include "Shape.h"

class ShapeCollision {

public:

    /**
 * Checks the entire vector of shapes, to see if any two shapes intersect
 * @param shapes the vector of shapes to check
 * @return true of any two shapes intersect, false otherwise
 */
    static bool shapeIntersections(std::vector<Shape> &shapes);

    size_t getFirstCollisionIndex();

    size_t getSecondCollisionIndex();

    void setFirstCollisionIndex(size_t newIndex);

    void setSecondCollisionIndex(size_t newIndex);

private:

    /**
* Checks if two shapes intersect in any way
* @param shape1 first shape
* @param shape2 second shape
* @return true if the shapes intersect, false otherwise
*/
    static bool pairIntersection(Shape &shape1, Shape &shape2);
    /**
 * Checks if there's been a line intersection
 * @param first point of the first line segment
 * @param second point of the first line segment
 * @param first point of the second line segment
 * @param second point of the second line segment
 * @return true if the lines intersect, false otherwise.
 */
    static bool lineIntersection(Point firstLinePoint1, Point firstLinePoint2, Point secondLinePoint1,
                          Point secondLinePoint2);

/**
 * Checks if a point lies within a shape
 * @param shape the shape we are to check
 * @param point  the point we are to check
 * @return true if the point indeed lies within the shape, false otherwise
 */
    static bool isPointInsideShape(Shape &shape, Point point);

    size_t firstCollisionIndex;
    size_t secondCollisionIndex;

};

#endif //EX2_SHAPECOLLISION_H
