#include "ShapeCollision.h"


/**
 * Checks if there's been a line intersection
 * @param first point of the first line segment
 * @param second point of the first line segment
 * @param first point of the second line segment
 * @param second point of the second line segment
 * @return true if the lines intersect, false otherwise.
 */
bool ShapeCollision::lineIntersection (Point firstLinePoint1, Point firstLinePoint2, Point secondLinePoint1,
                       Point secondLinePoint2)
{
    int orientation1 = Point::orientation(firstLinePoint1, firstLinePoint2, secondLinePoint1);
    int orientation2 = Point::orientation(firstLinePoint1, firstLinePoint2, secondLinePoint2);
    int orientation3 = Point::orientation(secondLinePoint1, secondLinePoint2, firstLinePoint1);
    int orientation4 = Point::orientation(secondLinePoint1, secondLinePoint2, firstLinePoint2);
    bool isOnSegment1 = Point::onSegment(firstLinePoint1, secondLinePoint1, firstLinePoint2);
    bool isOnSegment2 = Point::onSegment(firstLinePoint1, secondLinePoint2, firstLinePoint2);
    bool isOnSegment3 = Point::onSegment(secondLinePoint1, firstLinePoint1, secondLinePoint2);
    bool isOnSegment4 = Point::onSegment(secondLinePoint1, firstLinePoint2, secondLinePoint2);

    if (orientation1 != orientation2 && orientation3 != orientation4)
    {
        return true;
    }
    if (orientation1 == 0 && isOnSegment1)
    {
        return true;
    }
    if (orientation2 && isOnSegment2)
    {
        return true;
    }
    if (orientation3 && isOnSegment3)
    {
        return true;
    }
    if (orientation4 && isOnSegment4)
    {
        return true;
    }
    return false;
}


/**
 * Checks if a point lies within a shape
 * @param shape the shape we are to check
 * @param point  the point we are to check
 * @return true if the point indeed lies within the shape, false otherwise
 */
bool ShapeCollision::isPointInsideShape (Shape &shape, Point point)
{
    int vertices = (int)shape.points.size();
    Point infinityPoint(INFINITY, point.getY());
    int counter = 0;
    int i = 0;
    do
    {
        int next = (i + 1) % vertices;
        if (lineIntersection(shape.points[i], shape.points[next], point, infinityPoint))
        {
            if (Point::orientation(shape.points[i], point, shape.points[next]) == 0)
            {
                return Point::onSegment(shape.points[i], point, shape.points[next]);
            }
            counter++;
        }
        i = next;
    }
    while (i != 0);
    return counter % 2 == 0;
}

/**
 * Checks if two shapes intersect in any way
 * @param shape1 first shape
 * @param shape2 second shape
 * @return true if the shapes intersect, false otherwise
 */
bool ShapeCollision::pairIntersection (Shape &shape1, Shape &shape2)
{
    for (int i = 0; i < shape1.points.size(); i++)
    {
        for (int j = 0; j < shape2.points.size(); j++)
        {
            if (lineIntersection(shape1.points[i], shape1.points[(i+1)%shape1.points.size()],
                shape2.points[j], shape2.points[(j+1)%shape2.points.size()]) ||
                isPointInsideShape(shape1, shape2.points[j]) || isPointInsideShape(shape2, shape1.points[i]))
                return true;
        }
    }
    return false;
}

/**
 * Checks the entire vector of shapes, to see if any two shapes intersect
 * @param shapes the vector of shapes to check
 * @return true of any two shapes intersect, false otherwise
 */
bool ShapeCollision::shapeIntersections (std::vector<Shape> &shapes)
{
    for (size_t i = 0; i < shapes.size(); i++)
    {
        for (size_t j = 1; j < shapes.size(); i++)
        {
            if (pairIntersection(shapes.at(i), shapes.at(j)))
            {
                setFirstCollisionIndex(i);
                setSecondCollisionIndex(j);
                return true;
            }
        }
    }
    return false;
}

/**
 * Gets the first collision index, if one should exist
 * @return the first collision index
 */
size_t ShapeCollision::getFirstCollisionIndex()
{
    return firstCollisionIndex;
}

/**
 * Gets the second collision index, if one should exist
 * @return the second collision index
 */
size_t ShapeCollision::getSecondCollisionIndex()
{
 return secondCollisionIndex;
}

/**
 * sets the first colliision index, so we should find one
 * @param newIndex the index to which we'd like to set it.
 */
void ShapeCollision::setFirstCollisionIndex(size_t newIndex)
{
    firstCollisionIndex = newIndex;
}

/**
 * sets the second colliision index, so we should find one
 * @param newIndex the index to which we'd like to set it.
 */
void ShapeCollision::setSecondCollisionIndex(size_t newIndex)
{
    secondCollisionIndex = newIndex;
}
