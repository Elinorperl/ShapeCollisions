#include "Point.h"

/**
 * @def INITIAL_SIZE 0
 * @brief initializes objects at 0
 */
#define INITIAL_SIZE 0

#define COLLINEAR 0
#define CLOCKWISE 1
#define COUNTER_CLOCKWISE -1

// --------------------------------------------------------------------------------------
// This file contains the implementation of the class Point.
// --------------------------------------------------------------------------------------

/**
 * Default point constructor
 */
Point::Point()
{
    this->_x = INITIAL_SIZE;
    this->_y = INITIAL_SIZE;
}

/**
 * Point constructor
 * @param x the new x coordinate
 * @param y the new y coordinate
 * @return A point with new x and y axis
 */
Point::Point(CordType x, CordType y)
{
    this->_x = x;
    this->_y = y;
}


// ------------------ Access methods ------------------------

//double Point::getAngle(Point p)
//{
//    double dx = this->_x - p.getX();
//    double dy = this->_y - p.getY();
//    return atan2(dy, dx);
//}

/**
 * getter function
 * @return the x axis
 */
CordType Point::getX()
{
    return _x;
}

/**
 * getter function
 * @return the y axis
 */
CordType Point::getY()
{
    return _y;
}

/**
 * @param p a point to compare to
 * @return true if the points are equal, false otherwise
 */
bool Point::operator==(const Point p) const
{
    return (this->_x < p._x) && (this->_y < p._y);
}

/**
 * String representation of a point
 * @return a string of the point
 */
std::string Point::toString()
{
    std::string str = std::to_string(_x);
    str.append(",");
    str.append(std::to_string(_y));
    return str;
}

// ------------------ Modify methods ------------------------

/**
 * Setter function - sets the x and y points.
 * @param x x axis point
 * @param y y axis point
 */
void Point::set(CordType x, CordType y)
{
    this->_x = x;
    this->_y = y;
}



// ------------------ Operator methods ------------------------

/**
 * Point operator that compares the x axis, and if they are equal the y axis/
 * @param p the point to compare with
 * @return true if the current point is smaller than the given, false otherwise
 */
bool Point::operator<(const Point p) const
{
    if (_x != p._x)
    {
        return _x < p._x;
    }

    return _y < p._y;
}

/**
 * Checks the 3 points orientation in accordance to each other.
 * @param point1 first point
 * @param point2 second point
 * @param point3 third point
 * @return 0 if the points are collinear, -1, if their orientation is counter clockwise, 1 if
 * the orientation is clockwise.
 */
int Point::orientation (Point point1, Point point2, Point point3)
{
    CordType orientation = (point2.getX() - point1.getX()) * (point3.getY() - point1.getY()) -
                      (point2.getY() - point1.getY()) * (point3.getX() - point1.getX());

    if (orientation > COLLINEAR)
    {
        return COUNTER_CLOCKWISE;
    }
    if (orientation < COLLINEAR)
    {
        return CLOCKWISE;
    }
    return COLLINEAR;
}

/**
 * Checks if
 * @param point1 first point
 * @param point2 second point
 * @param point3 third point
 * @return true if the points are on the same segment, false otherwise.
 */
CordType Point::pointPosition (Point point1, Point point2, Point point3)
{
    return 0.5 * (((point1.getX() * (point2.getY() - point3.getY()))) - (point1.getY() *
            (point2.getX() - point3.getY())) + ((point2.getX() * point3.getY()) -
            (point2.getY() * point3.getX())));
}

/**
 * Checks the 3 points are on the same line segment.
 * @param point1 first point
 * @param point2 second point
 * @param point3 third point
 * @return true if the points are on the same segment, false otherwise.
 */
bool Point::onSegment (Point point1, Point point2, Point point3)
{
    return point2.getX() <= std::max(point1.getX(), point3.getX()) && point2.getX() >=
       std::min(point1.getX(), point3.getX()) && point2.getY() <= std::max(point1.getY(),
       point3.getY()) && point2.getY() >= std::min(point1.getY(), point3.getY());
}