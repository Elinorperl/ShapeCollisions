
#ifndef DEFS_H
#define DEFS_H

/*
* all calculation should be done with Epsilon accuracy.
*/
#define EPSILON (0.0001)

/*
* coordinate type
*/
typedef double CordType;





#endif