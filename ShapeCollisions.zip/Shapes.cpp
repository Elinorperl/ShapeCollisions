#include <vector>
#include "Shape.h"
#include "ShapeFactory.h"
#include "ShapeCollision.h"
#include "PrintOuts.h"

std::vector<Shape*> userInput()
{
    char type;
    std::vector<Shape*> allShapes;
    std::vector<Point> shapePoints;
    while (std::cin >> type)
    {
        while (std::cin.get() != '\n')
        {
            CordType x;
            CordType y;
            std::cin >> x >> y;
            Point point (x, y);
            shapePoints.push_back(point);
        }
        Shape *new_shape = ShapeFactory::createShape(type, shapePoints);
        allShapes.push_back(new_shape);
    }
    return allShapes;
}

double shapeAreas (std::vector<Shape> &shapes)
{
    double area = 0;
    for (size_t i = 0; i < shapes.size(); i++)
    {
        area += shapes.at(i).getArea();
    }
    return area;
}

Shape chooseShapeToPrint(Shape shape)
{
    if (shape.getName() == "Triangle")
    {
        printTrig(shape.points[0].getX(), shape.points[0].getY(), shape.points[1].getX(),
                  shape.points[1].getY(), shape.points[2].getX(), shape.points[2].getY());
    }
    else if (shape.getName() == "Trapezoid")
    {
        printTrapez(shape.points[0].getX(), shape.points[0].getY(), shape.points[1].getX(),
                    shape.points[1].getY(), shape.points[2].getX(), shape.points[2].getY(),
        shape.points[3].getX(), shape.points[3].getY());
    }
    reportDrawIntersect();
}

void printIntersection (std::vector<Shape> &shapes)
{
    if (ShapeCollision::shapeIntersections(shapes))
    {
        chooseShapeToPrint(shapes.at(ShapeCollision::getFirstCollisionIndex())); //todo can't be static what do i do??
        chooseShapeToPrint(shapes.at(ShapeCollision::getSecondCollisionIndex()));
    }
    else
    {
        double areaOfShapes = shapeAreas(shapes);
        printArea(areaOfShapes);
    }
}




int main (int argc, char* argv[])
{
    if (argc != 2 && argc != 3)
    {
        return 1;
    }
}

