#ifndef EX2_TRAPEZOID_H
#define EX2_TRAPEZOID_H

#include "Shape.h"
#define TRAPEZOID "Trapezoid"

/**
 * Trapezoid constructor which will create the Trapezoid only if it is valid
 * @param Point area containing 4 points
 */
class Trapezoid : public Shape
{
public:
    Trapezoid(std::vector<Point>&);

    static Trapezoid* createTrapezoid(std::vector<Point> &newPoints);

private:

    static bool trapezoidIsLegal(std::vector<Point> points);

    /**
 * Calculates the trapezoid area.
 */
    virtual void calculateArea();
};


#endif //EX2_TRAPEZOID_H