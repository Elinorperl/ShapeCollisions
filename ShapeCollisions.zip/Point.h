#ifndef _POINT_H
#define _POINT_H

#include <string>
#include <iostream>
#include "Defs.h"
#include <algorithm>

/**
 *  A point class.
 *  This class represents a point with (x,y) coordinates.
 */

class Point
{
public:

/**
 * A default constructor.
 */
    Point();
/**
 * @param x x coordinate
 * @param y y coordinate
* A constructor that places and x and y coordinate.
*/
    Point(CordType x, CordType y);
//    double getAngle(Point p);
//    double getAngle(Point p);
/**
 * Access method for the x value.
 * @return The x value
 */
    CordType getX();
/**
 * Access method for the y value.
 * @return The y value
 */
    CordType getY();
/**
 * returns the point as a string.
 * @return the string value of point
 */
    std::string toString();
/**
 * A set function to set the x and y coordinates to a new point.
 */
    void set(CordType x, CordType y);
/**
 * Checks if two points are equal.
 * @param p another point.
 * @return True if two points are equal, false otherwise.
 */
    bool operator==(const Point p) const;
/**
 * Checks if one point is smaller than the other.
 * @param p given point.
 * @return True if the current point is smaller than the given parameter, false otherwise.
 */
    bool operator<(const Point p) const;

    /**
     * Checks the 3 points orientation in accordance to each other.
     * @param point1 first point
     * @param point2 second point
     * @param point3 third point
     * @return 0 if the points are collinear, -1, if their orientation is counter clockwise, 1 if
     * the orientation is clockwise.
     */
    static int orientation (Point point1, Point point2, Point point3);
    /**
     * Checks the 3 points are on the same line segment.
     * @param point1 first point
     * @param point2 second point
     * @param point3 third point
     * @return true if the points are on the same segment, false otherwise.
     */
    static bool onSegment (Point point1, Point point2, Point point3);

    /**
     * Checks if 
     * @param point1 first point
     * @param point2 second point
     * @param point3 third point
     * @return true if the points are on the same segment, false otherwise.
     */
    static CordType pointPosition (Point point1, Point point2, Point point3);

private:
/**
 * The x coordinate for a Point.
 */
    CordType _x;
/**
 * The y coordinate for a Point.
 */
    CordType _y;
};

#endif