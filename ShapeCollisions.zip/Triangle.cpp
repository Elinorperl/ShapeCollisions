#include "Triangle.h"

/**
 * Triangle constructor according to 3 given points.
 * @param Point givenPoints[3] an array of points that contains 3 points of a triangle.
 */
Triangle :: Triangle(std::vector<Point> &givenPoints) : Shape("Triangle", givenPoints)
{
    calculateArea();
}

bool Triangle:: isTriangleLegal (std::vector<Point> givenPoints)
{
    return (givenPoints[1].getY() - givenPoints[0].getY()) * (givenPoints[2].getX() - givenPoints[1].getX()) !=
        (givenPoints[2].getY() - givenPoints[1].getY()) * (givenPoints[1].getX() - givenPoints[0].getX());
}

Triangle* Triangle::createTriangle(std::vector<Point> &givenPoints)
{
    if (isTriangleLegal(givenPoints))
    {
        Triangle *triangle = new Triangle(givenPoints);
        return triangle;
    }
}

/**
 * Calculate the triangles area
 */
void Triangle::calculateArea()
{
    double base1 = points[0].getX()*(points[1].getY() - points[2].getY());
    double base2 = points[1].getX()*(points[2].getY() - points[0].getY());
    double base3 = points[2].getX()*(points[0].getY() - points[1].getY());
    this->area = fabs((base1 + base2 + base3)/2);
}


