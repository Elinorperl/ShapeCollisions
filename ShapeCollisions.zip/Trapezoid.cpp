#include "Trapezoid.h"

Trapezoid:: Trapezoid(std::vector<Point> &newPoints) : Shape("Trapezoid", newPoints)
{
    calculateArea();
}

bool Trapezoid::trapezoidIsLegal(std::vector<Point> points)
{
    return (points[0].getY() == points[1].getY() || points[2].getY() == points[3].getY() ||
            points[0].getY() != points[2].getY());
}

Trapezoid* Trapezoid::createTrapezoid(std::vector<Point> &newPoints)
{
    if (trapezoidIsLegal(newPoints))
    {
        Trapezoid *trapezoid = new Trapezoid(newPoints);
        return trapezoid;
    }
}

/**
 * Calculates the trapezoid area.
 */
void Trapezoid ::calculateArea()
{
    double base1 = this->points[1].getX() - this->points[0].getX();
    double base2 = this->points[3].getX() - this->points[2].getX();
    double height = fabs(this->points[0].getY() - this->points[3].getY());
    this->area = ((base1 + base2)*height)/2;

}
